<!-- prettier-ignore -->
<div align="center">

<img src="https://raw.githubusercontent.com/zyycn/codex-proxy-rs/main/frontend/public/favicon.svg" alt="Codex Proxy UI" width="80" height="80" />

# Codex Proxy UI

面向管理工具与插件页面的 Vue 3 组件库

[![CI](https://github.com/zyycn/codex-proxy-ui/actions/workflows/ci.yml/badge.svg)](https://github.com/zyycn/codex-proxy-ui/actions/workflows/ci.yml)
[![Release](https://img.shields.io/github/v/release/zyycn/codex-proxy-ui?display_name=tag&sort=semver&style=flat-square)](https://github.com/zyycn/codex-proxy-ui/releases)
[![License: Apache 2.0](https://img.shields.io/badge/License-Apache%202.0-blue.svg?style=flat-square)](LICENSE)

[快速预览](#快速预览) · [快速开始](#快速开始) · [本地开发](#本地开发) · [文档](#文档)

</div>

## 快速预览

[Playground](https://zyycn.github.io/codex-proxy-ui/) 提供表单、表格、导航与反馈组件的交互示例，以及浅色、深色、自定义主题和示例源码

正式版本发布时自动构建并部署到 GitHub Pages，预发行只构建验收，不覆盖在线站点

## 快速开始

需要 Vue 3.5+，组件库提供 TypeScript 类型与完整样式，无需安装 Tailwind

### 安装

从 [GitHub Releases](https://github.com/zyycn/codex-proxy-ui/releases) 选择固定版本的安装包

```bash
pnpm add https://github.com/zyycn/codex-proxy-ui/releases/download/v0.4.0/codex-proxy-ui-0.4.0.tgz
```

包名为 `@codex-proxy/ui`，当前通过 GitHub Release 分发，尚未发布到 npm registry

每个版本提供 `.tgz` 和 `.sha256`，提交应用锁文件以固定版本与完整性摘要

### 初始化主题

在客户端入口导入样式并设置默认主题

```ts
import {
  applyResolvedTheme,
  DEFAULT_CUSTOM_THEME_COLOR,
  DEFAULT_THEME_COLOR,
  resolveTheme,
} from '@codex-proxy/ui/theme'
import '@codex-proxy/ui/styles.css'

applyResolvedTheme(
  document.documentElement,
  resolveTheme('light', DEFAULT_THEME_COLOR, DEFAULT_CUSTOM_THEME_COLOR),
)
```

### 使用组件

在 Vue 组件中直接导入，模板支持 `<z-button>` 与 `<ZButton>`

```vue
<script setup lang="ts">
import { ZButton, ZCard, ZInput } from '@codex-proxy/ui'
import { ref } from 'vue'

const name = ref('')
</script>

<template>
  <ZCard title="插件设置">
    <ZInput v-model="name" placeholder="插件名称" />
    <ZButton type="primary">
      保存
    </ZButton>
  </ZCard>
</template>
```

根入口的静态具名导入支持 JavaScript tree-shaking，也可以使用组件子路径

```ts
import { ZButton } from '@codex-proxy/ui/button'
```

`styles.css` 包含基础重置与完整组件样式，CSS 不随 JavaScript 按组件裁剪

需要切换主题、自定义配色或接入 Tailwind CSS 4 时，参阅 [主题指南](playground/guide/theme.md) 与 [样式集成](playground/guide/installation.md#样式边界)

## 本地开发

需要 Node.js 24+，pnpm 版本由 `package.json` 固定

```bash
pnpm install --frozen-lockfile
pnpm dev
```

打开 [本地 Playground](http://127.0.0.1:5176)，组件与文档修改会自动热更新

普通应用开发和生产构建都使用编译产物，联合修改组件源码时使用 `@codex-proxy/ui/vite` 的默认导出 `CodexProxyUI`，配置见 [源码联调指南](playground/guide/development.md)

检查与构建

```bash
pnpm lint
pnpm typecheck
pnpm build
pnpm build:playground
```

`prepack` 自动生成 JavaScript、CSS、Vite 适配器及类型声明

## 文档

| 任务       | 文档                                                            |
| ---------- | --------------------------------------------------------------- |
| 安装与接入 | [安装、按需导入与样式边界](playground/guide/installation.md)    |
| 组件架构   | [命名、目录与职责](playground/guide/architecture.md)            |
| 查找组件   | [组件目录与交互示例](playground/components/index.md)            |
| 定制主题   | [主题变量、配色与密度](playground/guide/theme.md)               |
| 联合开发   | [源码联调与热更新](playground/guide/development.md)             |
| 发布组件库 | [自动构建与 Playground 部署](.github/workflows/release.yml)     |
| 反馈问题   | [GitHub Issues](https://github.com/zyycn/codex-proxy-ui/issues) |
